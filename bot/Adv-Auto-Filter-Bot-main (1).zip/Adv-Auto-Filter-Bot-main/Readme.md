# Adv Auto Filter Bot

<p align="center">
  <a href="https://github.com/AlbertEinsteinTG/Adv-Auto-Filter-Bot/stargazers">
    <img src="https://img.shields.io/github/stars/AlbertEinsteinTG/Adv-Auto-Filter-Bot?style=social">

  </a>
  
  <a href="https://github.com/AlbertEinsteinTG/Adv-Auto-Filter-Bot/fork">
    <img src="https://img.shields.io/github/forks/AlbertEinsteinTG/Adv-Auto-Filter-Bot?label=Fork&style=social">

  </a>  
</p>


# Deprecate Version.... Use Latest One Given Below... 

<i>**[Latest Repo](https://github.com/AlbertEinsteinTG/Adv-Auto-Filter-Bot-V2)**</i>
